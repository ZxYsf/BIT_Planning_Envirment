% NLOPT_LD_AUGLAG_EQ: Augmented Lagrangian method for equality constraints (local, derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_AUGLAG_EQ
  val = 33;
