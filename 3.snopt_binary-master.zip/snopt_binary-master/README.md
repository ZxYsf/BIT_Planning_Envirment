# snopt_binary

## snopt library binary files

* `libsnopt7.so`  snopt7 fortran shared library
* `libsnopt7.a`   snopt7 fortran static library
* `libsnopt7_cpp.so` snopt7 c++ interface shared library to snopt7 fortran library.
* `libsnopt7_cpp.a`  snopt7 c++ interface static library to snopt7 fortran library.


## Install
```
bash install.sh
```

Done.
